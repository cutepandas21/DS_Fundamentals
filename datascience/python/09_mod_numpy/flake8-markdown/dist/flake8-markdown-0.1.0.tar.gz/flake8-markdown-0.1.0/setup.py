# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flake8_markdown']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'flake8-markdown',
    'version': '0.1.0',
    'description': 'This is my second Python package',
    'long_description': None,
    'author': 'Gary Jackson',
    'author_email': 'gary.jackson@qlx.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
